#!/bin/bash

cat *.ttl > ../KG.ttl