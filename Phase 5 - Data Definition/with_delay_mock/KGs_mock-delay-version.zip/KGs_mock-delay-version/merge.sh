#!/bin/bash

cat *.ttl >> ../ALL_KG_with_delay_mock.ttl