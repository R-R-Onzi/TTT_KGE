#!/bin/bash

cat *.ttl >> ../ALL_KG.ttl